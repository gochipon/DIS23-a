package com.example.dietapp;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

public class Graph extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_graph);

        GraphView weightGraph = findViewById(R.id.weightGraph);
        GraphView caloriesGraph = findViewById(R.id.caloriesGraph);

        // 体重変化のデータ
        DataPoint[] weightData = new DataPoint[]{
                new DataPoint(1, 58),
                new DataPoint(2, 57.8),
                new DataPoint(3, 57.6),
                new DataPoint(4, 57.5),
                new DataPoint(5, 57.3),
                new DataPoint(6, 57.1),
                new DataPoint(7, 57),
                new DataPoint(8, 56.8),
                new DataPoint(9, 56.6),
                new DataPoint(10, 56.5),
                new DataPoint(11, 56.4),
                new DataPoint(12, 56.3),
                new DataPoint(13, 56.2),
                new DataPoint(14, 56)
        };

// カロリー消費量のデータ
        DataPoint[] caloriesData = new DataPoint[]{
                new DataPoint(1, 2300),
                new DataPoint(2, 2200),
                new DataPoint(3, 2250),
                new DataPoint(4, 2100),
                new DataPoint(5, 2400),
                new DataPoint(6, 2350),
                new DataPoint(7, 2200),
                new DataPoint(8, 2100),
                new DataPoint(9, 2300),
                new DataPoint(10, 2200),
                new DataPoint(11, 2150),
                new DataPoint(12, 2100),
                new DataPoint(13, 2350),
                new DataPoint(14, 2200)
        };

        weightGraph.addSeries(new LineGraphSeries<>(weightData));
        caloriesGraph.addSeries(new LineGraphSeries<>(caloriesData));
    }
}
